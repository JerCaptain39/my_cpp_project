// Soln3_1C.cpp
#include <iostream>
using std::cin;
using std::cout;
using std::endl;

int main()
{
   int total = 0;
   cout << "Enter numbers, one per line. Enter 0 to end:\n";

   // We don't need the increment expression
   for ( int val = 1 ; val != 0 ;)
   {
     cin >> val;
     total += val;
   }

   cout << "\nThank you. The total was " << total;
   cout << endl;

   return 0;
}
