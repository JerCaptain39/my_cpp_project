// Soln8_05.cpp

// I also added a move assignment operator

#include <iostream>                   // For stream input/output
#include <cstring>

using std::cout;
using std::endl;

class CSimpleString
{
private:
   size_t len;
   char* buff;
public:
   CSimpleString(const char* p = nullptr);
   CSimpleString(const CSimpleString& s);
   CSimpleString(char c, int count=1);
   CSimpleString(int i);

   ~CSimpleString();

   CSimpleString& operator=(const CSimpleString& rhs);
   CSimpleString& operator=(CSimpleString&& rhs);          // Move assignment

   CSimpleString& operator+=(const CSimpleString& rhs);
   CSimpleString operator+(const CSimpleString& s);
   CSimpleString operator+(const char* s);

   void print();
};

// Contructor - repeated given character
CSimpleString::CSimpleString(char c, int count) : buff(nullptr)
{
   len = count;
   if (len)
   {
      buff = new char[len + 1];
      memset(buff, c, len);
      buff[len] = '\0';
   }
}

// Constructor - from an integer
CSimpleString::CSimpleString(int i) : buff(nullptr)
{
   char sTmp[20];
   _itoa_s(i, sTmp, _countof(sTmp), 10);

   len = strlen(sTmp);
   if (len)
   {
      buff = new char[len + 1];
      strcpy_s(buff, len + 1, sTmp);
   }
}

// Constructor
CSimpleString::CSimpleString(const char* p) : len(0), buff(nullptr)
{
   if (p)
   {
      len = strlen(p);
      if (len)
      {
         buff = new char[len + 1];
         strcpy_s(buff, len + 1, p);
      } 
   }
}

// Copy constructor
CSimpleString::CSimpleString(const CSimpleString& s)
{
  cout << "Copy constructor" << endl;
   len = s.len;
   buff = new char[len + 1];
   strcpy_s(buff, len + 1, s.buff);
}

// Destructor
CSimpleString::~CSimpleString()
{
   delete [] buff;
}

// Assignment operator - does deal with str = str
CSimpleString& CSimpleString::operator=(const CSimpleString& rhs)
{
  if(this != &rhs)
  {
    cout << "Assignment" << endl;
    len = rhs.len;
    delete buff;
    buff = new char[len + 1];
    strcpy_s(buff, len + 1, rhs.buff);
  }
  return *this;
}

// Move assignment operator
CSimpleString& CSimpleString::operator=(CSimpleString&& rhs)
{
  if(this != &rhs)
  {
    cout << "Move assignment" << endl;
    len = rhs.len;
    delete [] buff;
    buff = rhs.buff;
    rhs.buff = nullptr;
  }
  return *this;
}

// Addition operator: add two CSimpleString objects
CSimpleString CSimpleString::operator+(const CSimpleString& s)
{
   cout << "Addition" << endl;
   size_t length = len + s.len + 1;
   char* tmp = new char[length];
   strcpy_s(tmp, length, buff);
   strcat_s(tmp, length, s.buff);

   return CSimpleString(tmp);
}

// Addition operator: CSimpleString object + string constant
CSimpleString CSimpleString::operator+(const char* s)
{
  return *this + CSimpleString(s);
}

// += operator
CSimpleString& CSimpleString::operator+=(const CSimpleString& rhs)
{
   *this = *this + rhs;
   return *this;
}

void CSimpleString::print()
{
   cout << buff;
}

int main()
{
   CSimpleString s1("hello");
   CSimpleString s2;

   s2 = s1;
   CSimpleString marker = CSimpleString('*', 30);
   marker.print();
   cout << endl;

   cout << "s1 = \"";
   s1.print();

   cout << "\"" << endl;

   cout << "s2 = \"";
   s2.print();
   cout << "\"" << endl;

   int n = 7890;

   CSimpleString nStr = CSimpleString(n);

   cout << n << " as a string is \"";
   nStr.print();
   cout << "\"" << endl;

   CSimpleString* pStr = &s2;

   s2 = *pStr;      // s2 = s2
   cout << "s2 = \"";
   s2.print();
   cout << "\"" << endl;

   s1 += " world!";

   cout << "s1 = \"";
   s1.print();

   cout << "\"" << endl;

   marker.print();
   cout << endl;

   CSimpleString space(" ");
   s2 = s1 + space + s1 + space + s1;
   s2.print();
   cout << endl;

   return 0;
}
