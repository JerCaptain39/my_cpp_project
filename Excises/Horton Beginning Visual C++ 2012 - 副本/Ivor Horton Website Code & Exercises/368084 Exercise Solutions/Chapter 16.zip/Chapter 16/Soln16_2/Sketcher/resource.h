//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Sketcher.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_SketchTYPE                  130
#define ID_WINDOW_MANAGER               131
#define IDR_CONTEXT_MENU                310
#define IDD_PENWIDTH_DLG                312
#define IDC_PENWIDTH0                   1000
#define IDC_PENWIDTH1                   1001
#define IDC_LIST1                       1001
#define IDC_PENWIDTH_LIST               1001
#define IDC_PENWIDTH2                   1002
#define IDC_PENWIDTH3                   1003
#define IDC_PENWIDTH4                   1004
#define IDC_PENWIDTH6                   1005
#define IDC_PENWIDTH5                   1005
#define ID_ELEMENT_LINE                 32771
#define ID_ELEMENT_RECTANGLE            32772
#define ID_ELEMENT_CIRCLE               32773
#define ID_ELEMENT_CURVE                32774
#define ID_COLOR_BLACK                  32775
#define ID_COLOR_RED                    32776
#define ID_COLOR_GREEN                  32777
#define ID_COLOR_BLUE                   32778
#define ID_BUTTON32790                  32790
#define ID_ELEMENT_MOVE                 32791
#define ID_ELEMENT_DELETE               32792
#define ID_ELEMENT_SENDTOBACK           32793
#define ID_PEN_WIDTH                    32794

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        313
#define _APS_NEXT_COMMAND_VALUE         32796
#define _APS_NEXT_CONTROL_VALUE         1002
#define _APS_NEXT_SYMED_VALUE           310
#endif
#endif
