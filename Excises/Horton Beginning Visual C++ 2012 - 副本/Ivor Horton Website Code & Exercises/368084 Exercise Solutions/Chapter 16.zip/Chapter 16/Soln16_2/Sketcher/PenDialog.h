#pragma once


// CPenDialog dialog

class CPenDialog : public CDialogEx
{
	DECLARE_DYNAMIC(CPenDialog)

public:
	CPenDialog(CWnd* pParent = NULL);                    // standard constructor
	virtual ~CPenDialog();

// Dialog Data
	enum { IDD = IDD_PENWIDTH_DLG };
protected:
	virtual void DoDataExchange(CDataExchange* pDX);     // DDX/DDV support

	DECLARE_MESSAGE_MAP()
  virtual void OnOK();
public:
  virtual BOOL OnInitDialog();
  int m_PenWidth;
};
