// PenDialog.cpp : implementation file
//

#include "stdafx.h"
#include "Sketcher.h"
#include "PenDialog.h"
#include "afxdialogex.h"


// CPenDialog dialog

IMPLEMENT_DYNAMIC(CPenDialog, CDialogEx)

CPenDialog::CPenDialog(CWnd* pParent /*=NULL*/)
	: CDialogEx(CPenDialog::IDD, pParent) , m_PenWidth(0)
{

}

CPenDialog::~CPenDialog()
{
}

void CPenDialog::DoDataExchange(CDataExchange* pDX)
{
  CDialogEx::DoDataExchange(pDX);
  DDX_CBIndex(pDX, IDC_PENWIDTH_COMBO, m_PenWidth);
  DDV_MinMaxInt(pDX, m_PenWidth, 0, 5);
}


BEGIN_MESSAGE_MAP(CPenDialog, CDialogEx)
END_MESSAGE_MAP()


// CPenDialog message handlers


void CPenDialog::OnOK()
{
  // TODO: Add your specialized code here and/or call the base class

  CDialogEx::OnOK();
}


BOOL CPenDialog::OnInitDialog()
{
  CDialogEx::OnInitDialog();
  CComboBox* pComboBox = static_cast<CComboBox*>(GetDlgItem(IDC_PENWIDTH_COMBO));
  CString penWidthStr;

  // The first string in the combo box is a special case
  penWidthStr.Format(_T("Pen Width 1 pixel"));
  pComboBox->AddString(penWidthStr);

  // Now add the remaining strings
  for(int i = 1 ; i <= 5 ; ++i)
  {
    penWidthStr.Format(_T("Pen Width 0.0%d inches"), i);
    pComboBox->AddString(penWidthStr);
  }
  pComboBox->SetCurSel(m_PenWidth);        // Set current scale

  return TRUE;  // return TRUE unless you set the focus to a control
  // EXCEPTION: OCX Property Pages should return FALSE
}
