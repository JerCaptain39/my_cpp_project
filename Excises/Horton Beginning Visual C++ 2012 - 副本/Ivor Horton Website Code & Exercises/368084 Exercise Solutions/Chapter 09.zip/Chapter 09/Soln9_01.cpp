// Soln 9_01.cpp

/*
  CBadClass initializes the member p in the contructor with the address passed as the argument.
  The argument to the constructor could be a string allocated on the heap that could be 
  destroyed externally. This would leave the object with an invalid pointer.
  The constructor should copy the argument and there should be a destructor to release the memory for p.
  It is also possible the argument to the constructor could be null.
  The default constructor does not initialize the members at all.
  The class allocates memory on the heap so it shuold implement a destructor, a copy constructor and an assignment operator.
  It is also desirable that the class implementa a move constructor and a move assignment operator.
  The class would be better defined as below.

*/
#include <cstring>

class CBadClass
{
private:
   int len;
   char* p;
public:
  CBadClass(const char* str=nullptr) : len(0), p(nullptr)
  {
    if(str)
    {
      len = strlen(str);
      p = new char[len+1];
      strcpy_s(p, len+1, str);
    }
  }

  // Copy constructor
  CBadClass(const CBadClass& obj) : len(0), p(nullptr)
  {
    if(obj.p)
    {
      len = strlen(obj.p);
      p = new char[len+1];
      strcpy_s(p, len+1, obj.p);
    }
  }

  // Move copy constructor
  CBadClass(CBadClass&& obj)
  {
      len = obj.len;
      p = obj.p;
      obj.p = nullptr;
  }

  // Destructor
  ~CBadClass()
  {
    delete [] p;
  }

  // Assignment operator
  CBadClass& operator=(const CBadClass& obj)
  {
    if(this != &obj)
    {
      delete[] p;
      p = nullptr;
      len = 0;
      if(obj.p)
      {
        len = obj.len;
        p = new char[len+1];
        strcpy_s(p, len+1, obj.p);
      }
    }
    return *this;
  }

  // Move assignment operator
  CBadClass& operator=(CBadClass&& obj)
  {
    delete[] p;
    len = obj.len;
    p = obj.p;
    obj.p = nullptr;
    return *this;
  }
};

  // This is here so you can compile the class
  int main()
  {
    CBadClass obj("Test it!");
  }
