Solutions to Exercise 1 in Chapter 15


-This is trivial to implement. All that is necessary is to change the first parameter for the CreatePen() function in the CElement base class.



