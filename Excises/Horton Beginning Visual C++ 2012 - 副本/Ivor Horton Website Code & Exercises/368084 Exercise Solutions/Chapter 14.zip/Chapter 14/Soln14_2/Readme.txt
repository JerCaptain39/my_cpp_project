Solutions to Exercise 2 in Chapter 14


-Modified the CreateElement() member of CSketcherView with a case statement to create a CEllipse object when  the element type is ElementType::ELLIPSE.

-The Draw() member of the CEllipse class was implemented in the solution to Exercise 1 in  this chapter. 


