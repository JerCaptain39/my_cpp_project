Solutions to Exercise 3 in Chapter 14


-Only the CEllipse constructor needs to be modified to create an ellipse with the first point as the center and the second as a corner of the enclosing rectangle.
You just have to figure out what the top left and bottom right points of the defining rectangle are.




