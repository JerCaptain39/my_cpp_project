// Soln10_03.cpp
// Using a multimap container to support multiple phone numbers per person
        
#include <iostream>
#include <iomanip>
#include <string>
#include <map>
#include "Person.h"
        
using std::cin;
using std::cout;
using std::endl;
using std::setw;
using std::ios;
using std::string;

typedef std::multimap<Person, string> PhoneBook;
typedef std::pair<Person, string> Entry;

// Read a person from cin
Person getPerson()
{
  string first;
  string second;
  cout << "Enter a first name: " ;
  getline(cin, first);
  cout << "Enter a second name: " ;
  getline(cin, second);
  return Person(first, second);
}

// Read a phone book entry from standard input
Entry inputEntry()
{
  Person person = getPerson();
  string number;
  cout << "Enter the phone number for " << person.getName() << ": ";
  getline(cin, number);
  return std::make_pair(std::move(person), std::move(number));
}

// Add a new entry to a phone book - always possible
void addEntry(PhoneBook& book)
{
  book.emplace(inputEntry());        
}
        
// List the contents of a phone book
void listEntries(const PhoneBook& book)
{
  if(book.empty())
  {
    cout << "The phone book is empty." << endl;
    return;
  }
  cout << setiosflags(ios::left);      // Left justify output

  string previousName;
  for(auto& entry : book)
  {
    if(previousName == entry.first.getName())
    {
      cout << setw(30) << " " << " : " 
           << setw(12) << entry.second << endl;
    }
    else
    {
      previousName = entry.first.getName();
      cout  << endl 
           << setw(30) << previousName << " : "
           << setw(12) << entry.second << endl;
    }
  }
  cout << resetiosflags(ios::right);   // Right justify output
}
        
// Retrieve an entry from a phone book
void getEntry(const PhoneBook& book)
{
  Person person = getPerson();
  auto iter = book.find(person);
  if(iter == book.end())
  { // No entries
    cout << "No entry found for " << person.getName() << endl;
  }
  else
  { // At least one entry
    cout << "The number(s) for " << person.getName()  << " are: " << endl;
    for( ; iter != book.upper_bound(person) ; ++iter)
      cout << setw(24) << iter->second << endl;
  }
}
        
// Delete an entry from a phone book
void deleteEntry(PhoneBook& book)
{
  Person person = getPerson();
  size_t entries(book.count(person));  // Get number of entries for person

  if(entries == 0) 
  { // There are no entries.
    cout << "No entry found for " << person.getName() << endl;
  }
  else if(entries > 1)
  { // Multiple entries - so ask which one to erase.
    string number;
    cout << "The number(s) for " << person.getName()  << " are: " << endl;
    for(auto iter = book.find(person) ; iter != book.upper_bound(person) ; ++iter)
      cout << setw(24) << iter->second << endl;

    cout << "Which one do you want to delete: ";
    getline(cin, number);
    for(auto iter = book.find(person) ; iter != book.upper_bound(person) ; ++iter)
    { // Find the number
      if(number == iter->second)
      {
        book.erase(iter);              // Found it so erase
        break;
      }
    }
     cout << " The number " << number << " for " << person.getName() << " erased." << endl;
  }
  else
  { // Only one entry - so erase it.
    book.erase(book.find(person));
     cout << " The entry for " << person.getName() << " erased." << endl;
  }
}
        
int main()
{
  PhoneBook phonebook;
  char answer = 0;
        
  while(true)
  {
    cout << "Do you want to enter a phone book entry(Y or N): " ;
    cin >> answer;
    cin.ignore();                      // Ignore newline in buffer
    if(toupper(answer) == 'N')
      break;
    if(toupper(answer) != 'Y')
    {
      cout << "Invalid response. Try again." << endl;
      continue;
    }
    addEntry(phonebook);
  }
        
  // Query the phonebook
  while(true)
  {
    cout << endl << "Choose from the following options:" << endl
         << "A  Add an entry   D Delete an entry   G  Get an entry" << endl
         << "L  List entries   Q  Quit" << endl;
    cin >> answer;
    cin.ignore();                      // Ignore newline in buffer
        
    switch(toupper(answer))
    {
      case 'A':
        addEntry(phonebook);
        break;
      case 'G':
        getEntry(phonebook);
        break;
      case 'D':
        deleteEntry(phonebook);
        break;
      case 'L':
        listEntries(phonebook);
        break;
      case 'Q':
        return 0;
      default:
        cout << "Invalid selection. Try again." << endl;
        break;
    }
  }
  return 0;
}
